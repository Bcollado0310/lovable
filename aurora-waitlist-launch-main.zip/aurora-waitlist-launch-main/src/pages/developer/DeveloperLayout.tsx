import { Outlet } from "react-router-dom";
import { DeveloperSidebar } from "@/components/developer/DeveloperSidebar";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";

export default function DeveloperLayout() {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <DeveloperSidebar />
        
        <main className="flex-1">
          <header className="h-14 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 flex items-center px-6">
            <SidebarTrigger />
            <div className="ml-4">
              <h1 className="text-lg font-semibold">Developer Portal</h1>
            </div>
          </header>
          
          <div className="p-6">
            <Outlet />
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}