import { useState, useEffect } from "react";
import { LayoutHeader } from "@/components/layout/LayoutHeader";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  User, 
  Mail, 
  Shield, 
  Settings, 
  Bell,
  CreditCard,
  Download
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Profile {
  id: string;
  created_at: string;
}

export default function AccountPage() {
  const { user, isAdmin } = useAuth();
  const { toast } = useToast();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchProfile();
    } else if (user === null) {
      // If user is explicitly null (not loading), stop loading
      setLoading(false);
    }
  }, [user]);

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user?.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        // PGRST116 is "not found" error, which is okay
        console.error('Error fetching profile:', error);
      }

      setProfile(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
      // Don't let profile errors block the account page
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-pulse gradient-text text-lg">Loading account...</div>
      </div>
    );
  }

  const memberSince = profile?.created_at 
    ? new Date(profile.created_at).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long'
      })
    : user?.created_at
    ? new Date(user.created_at).toLocaleDateString('en-US', {
        year: 'numeric', 
        month: 'long'
      })
    : 'Unknown';

  return (
    <div className="min-h-screen bg-background">
      <LayoutHeader title="Account Settings" />
      
      <div className="max-w-4xl mx-auto p-6 space-y-6">

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Profile Information */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="glass-card border-glass-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5 text-primary" />
                  Profile Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      value={user?.email || ''}
                      disabled
                      className="glass border-glass-border"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="member-since">Member Since</Label>
                    <Input
                      id="member-since"
                      value={memberSince}
                      disabled
                      className="glass border-glass-border"
                    />
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Badge className="bg-primary/20 text-primary border-primary/30">
                    <Shield className="h-3 w-3 mr-1" />
                    Verified Investor
                  </Badge>
                  {isAdmin && (
                    <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                      <Settings className="h-3 w-3 mr-1" />
                      Administrator
                    </Badge>
                  )}
                </div>

                <div className="pt-4">
                  <Button className="bg-gradient-primary hover:shadow-neon">
                    Update Profile
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Security Settings */}
            <Card className="glass-card border-glass-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  Security & Privacy
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Password</h4>
                    <p className="text-sm text-muted-foreground">
                      Last updated: Never changed
                    </p>
                  </div>
                  <Button variant="outline" className="glass border-glass-border">
                    Change Password
                  </Button>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Two-Factor Authentication</h4>
                    <p className="text-sm text-muted-foreground">
                      Add an extra layer of security
                    </p>
                  </div>
                  <Button variant="outline" className="glass border-glass-border">
                    Enable 2FA
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Preferences */}
            <Card className="glass-card border-glass-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5 text-primary" />
                  Notification Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Investment Updates</h4>
                      <p className="text-sm text-muted-foreground">
                        Property performance and dividend notifications
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      defaultChecked
                      className="w-4 h-4 accent-primary"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">New Opportunities</h4>
                      <p className="text-sm text-muted-foreground">
                        Get notified about new investment properties
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      defaultChecked
                      className="w-4 h-4 accent-primary"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Marketing Communications</h4>
                      <p className="text-sm text-muted-foreground">
                        Market insights and Aurora Equity news
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      className="w-4 h-4 accent-primary"
                    />
                  </div>
                </div>
                
                <div className="pt-4">
                  <Button 
                    onClick={() => toast({ title: "Preferences saved!" })}
                    className="bg-gradient-primary hover:shadow-neon"
                  >
                    Save Preferences
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Account Summary Sidebar */}
          <div className="space-y-6">
            <Card className="glass-card border-glass-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-primary" />
                  Account Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <User className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <h3 className="font-semibold gradient-text">{user?.email}</h3>
                  <p className="text-sm text-muted-foreground">Premium Investor</p>
                </div>
                
                <div className="space-y-2 pt-4 border-t border-glass-border">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Account Status:</span>
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      Active
                    </Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Verification:</span>
                    <Badge className="bg-primary/20 text-primary border-primary/30">
                      Verified
                    </Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Member Since:</span>
                    <span>{memberSince}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-glass-border">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Download className="h-5 w-5 text-primary" />
                  Documents
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full glass border-glass-border justify-start"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Tax Documents (2024)
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full glass border-glass-border justify-start"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Investment Summary
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full glass border-glass-border justify-start"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Portfolio Statement
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}