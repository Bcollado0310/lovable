import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface MediaItem {
  id: string;
  offering_id: string;
  url: string;
  kind: 'image' | 'video';
  position: number;
  is_hero: boolean;
  alt_text: string | null;
  caption: string | null;
  visibility: 'public' | 'private';
  thumbnail_url: string | null;
  medium_url: string | null;
  width: number | null;
  height: number | null;
  duration: number | null;
  poster_url: string | null;
  size_bytes: number | null;
  filename: string | null;
  created_at: string;
  updated_at: string;
}

export function useMediaManagement(offeringId: string) {
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  const fetchMedia = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('offering_media')
        .select('*')
        .eq('offering_id', offeringId)
        .order('position', { ascending: true });

      if (error) throw error;
      setMediaItems((data || []) as MediaItem[]);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to load media',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [offeringId, toast]);

  const updateMediaOrder = useCallback(async (items: MediaItem[]) => {
    try {
      const updates = items.map((item, index) => ({
        id: item.id,
        position: index,
      }));

      for (const update of updates) {
        const { error } = await supabase
          .from('offering_media')
          .update({ position: update.position })
          .eq('id', update.id);

        if (error) throw error;
      }

      setMediaItems(items);
      toast({
        title: 'Success',
        description: 'Media order updated',
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update order',
        variant: 'destructive',
      });
    }
  }, [toast]);

  const setHeroImage = useCallback(async (mediaId: string) => {
    try {
      const { error } = await supabase
        .from('offering_media')
        .update({ is_hero: true })
        .eq('id', mediaId);

      if (error) throw error;

      setMediaItems(prev =>
        prev.map(item => ({
          ...item,
          is_hero: item.id === mediaId,
        }))
      );

      toast({
        title: 'Success',
        description: 'Hero image updated',
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to set hero image',
        variant: 'destructive',
      });
    }
  }, [toast]);

  const updateMedia = useCallback(async (
    mediaId: string,
    updates: Partial<MediaItem>
  ) => {
    try {
      const { error } = await supabase
        .from('offering_media')
        .update(updates)
        .eq('id', mediaId);

      if (error) throw error;

      setMediaItems(prev =>
        prev.map(item =>
          item.id === mediaId ? { ...item, ...updates } : item
        )
      );

      toast({
        title: 'Success',
        description: 'Media updated',
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update media',
        variant: 'destructive',
      });
    }
  }, [toast]);

  const deleteMedia = useCallback(async (mediaIds: string[]) => {
    try {
      // Optimistically remove from UI
      const removedItems = mediaItems.filter(item => mediaIds.includes(item.id));
      setMediaItems(prev => prev.filter(item => !mediaIds.includes(item.id)));
      setSelectedItems(new Set());

      // Delete from database with dev bypass header
      const { error } = await supabase
        .from('offering_media')
        .delete()
        .in('id', mediaIds);

      if (error) {
        // Revert on error
        setMediaItems(prev => [...prev, ...removedItems].sort((a, b) => a.position - b.position));
        throw error;
      }

      toast({
        title: 'Success',
        description: `${mediaIds.length} item(s) deleted`,
      });

      return true;
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete media',
        variant: 'destructive',
      });
      return false;
    }
  }, [mediaItems, toast]);

  const toggleSelection = useCallback((mediaId: string) => {
    setSelectedItems(prev => {
      const next = new Set(prev);
      if (next.has(mediaId)) {
        next.delete(mediaId);
      } else {
        next.add(mediaId);
      }
      return next;
    });
  }, []);

  const selectAll = useCallback(() => {
    setSelectedItems(new Set(mediaItems.map(item => item.id)));
  }, [mediaItems]);

  const clearSelection = useCallback(() => {
    setSelectedItems(new Set());
  }, []);

  return {
    mediaItems,
    loading,
    selectedItems,
    fetchMedia,
    updateMediaOrder,
    setHeroImage,
    updateMedia,
    deleteMedia,
    toggleSelection,
    selectAll,
    clearSelection,
  };
}
