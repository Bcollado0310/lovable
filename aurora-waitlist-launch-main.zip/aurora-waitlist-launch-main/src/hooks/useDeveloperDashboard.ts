import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useDeveloperAuth } from '@/contexts/DeveloperAuthContext';

interface DashboardMetrics {
  totalRaised: number;
  totalInvestors: number;
  activeOfferings: number;
  completedOfferings: number;
  totalDistributions: number;
  avgInvestmentSize: number;
}

interface DashboardData {
  metrics: DashboardMetrics;
  offerings: any[];
  investors: any[];
  activity: any[];
  organization: any;
  error?: string;
}

export function useDeveloperDashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { organization } = useDeveloperAuth();

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      setError(null);

      const orgId = organization?.id || '550e8400-e29b-41d4-a716-446655440000';
      
      console.log('useDeveloperDashboard: Fetching dashboard for orgId:', orgId);

      const { data: responseData, error: functionError } = await supabase.functions.invoke('dev-dashboard', {
        body: { orgId },
      });

      console.log('useDeveloperDashboard: Raw response:', { responseData, functionError });

      if (functionError) {
        console.error('useDeveloperDashboard: Function error:', functionError);
        // Try to provide more context about the error
        const errorMessage = functionError.message || 'Unknown function error';
        throw new Error(`Dashboard API error: ${errorMessage}`);
      }

      if (responseData?.error) {
        console.warn('useDeveloperDashboard: Dashboard returned error:', responseData.error);
        setError(responseData.error);
      }

      console.log('useDeveloperDashboard: Dashboard data received:', {
        organizationName: responseData?.organization?.name,
        offeringsCount: responseData?.offerings?.length || 0,
        investorsCount: responseData?.investors?.length || 0,
        activityCount: responseData?.activity?.length || 0,
        totalRaised: responseData?.metrics?.totalRaised || 0,
      });

      setData(responseData);
    } catch (err) {
      console.error('useDeveloperDashboard: Error:', err);
      setError(err instanceof Error ? err.message : 'Failed to load dashboard');
      
      // Set empty data on error
      setData({
        metrics: {
          totalRaised: 0,
          totalInvestors: 0,
          activeOfferings: 0,
          completedOfferings: 0,
          totalDistributions: 0,
          avgInvestmentSize: 0,
        },
        offerings: [],
        investors: [],
        activity: [],
        organization: null,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, [organization?.id]);

  return { 
    data, 
    loading, 
    error, 
    refetch: fetchDashboard 
  };
}