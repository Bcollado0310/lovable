import { useState, useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip-portal";
import { Info, DollarSign, TrendingUp, Percent, Calculator, Target, Clock, Building2, Calendar } from "lucide-react";
import { AnimatedCounter } from "@/components/AnimatedCounter";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { dashboardAnalytics } from "@/utils/analytics";

interface KPIData {
  cash_available: number;
  total_invested: number;
  current_value: number;
  total_distributions: number;
  unfunded_commitments: number;
  active_investments: number;
}

interface KPIStripProps {
  data: KPIData;
  mode?: 'simple' | 'pro';
}

export function KPIStrip({ data, mode = 'pro' }: KPIStripProps) {
  const [selectedRange, setSelectedRange] = useLocalStorage<"1m" | "3m" | "6m" | "1y" | "ytd" | "inception">("kpi-selected-range", "inception");
  const [openTooltip, setOpenTooltip] = useState<string | null>(null);

  // Format currency consistently
  const formatCurrency = (amount: number) => {
    return `$${amount.toLocaleString()}`;
  };

  // Calculate derived metrics based on selected range
  const getAdjustedData = () => {
    // In production, this would filter data based on the selected time range
    // For now, we'll apply different multipliers to simulate time-based changes
    const multipliers = {
      "1m": 0.1,
      "3m": 0.25,
      "6m": 0.5,
      "1y": 0.8,
      "ytd": 0.7,
      "inception": 1.0
    };
    
    const multiplier = multipliers[selectedRange];
    return {
      ...data,
      total_distributions: data.total_distributions * multiplier,
      current_value: data.total_invested + (data.current_value - data.total_invested) * multiplier
    };
  };

  const adjustedData = getAdjustedData();
  const netReturn = adjustedData.current_value + adjustedData.total_distributions - adjustedData.total_invested;
  const netReturnPercentage = adjustedData.total_invested > 0 
    ? ((netReturn / adjustedData.total_invested) * 100).toFixed(2)
    : "0.00";
  
  const moic = adjustedData.total_invested > 0 
    ? ((adjustedData.current_value + adjustedData.total_distributions) / adjustedData.total_invested).toFixed(2)
    : "0.00";

  // Mock IRR calculation - would vary by time range in production
  const irrByRange = {
    "1m": "2.1",
    "3m": "8.4", 
    "6m": "11.2",
    "1y": "12.5",
    "ytd": "10.8",
    "inception": "14.2"
  };
  const portfolioIRR = irrByRange[selectedRange];

  // Get next payout info for simple mode
  const nextPayout = {
    date: "Feb 15, 2024",
    amount: 2500
  };

  const simpleKpis = [
    {
      label: "Cash Available",
      value: formatCurrency(adjustedData.cash_available),
      numericValue: adjustedData.cash_available,
      sublabel: "Ready to invest",
      icon: DollarSign,
      tooltip: "Funds ready to invest or withdraw."
    },
    {
      label: "Current Value",
      value: formatCurrency(adjustedData.current_value),
      numericValue: adjustedData.current_value,
      sublabel: "Portfolio value",
      icon: TrendingUp,
      tooltip: "Estimated current portfolio value including accrued income."
    },
    {
      label: "Net Return %",
      value: `${netReturn >= 0 ? '+' : ''}${netReturnPercentage}%`,
      numericValue: parseFloat(netReturnPercentage),
      sublabel: "Total return",
      icon: Percent,
      tooltip: "(Current Value + Distributions − Total Invested) ÷ Total Invested."
    },
    {
      label: "Unfunded Commitments",
      value: formatCurrency(adjustedData.unfunded_commitments),
      numericValue: adjustedData.unfunded_commitments,
      sublabel: "Pending funding",
      icon: Clock,
      tooltip: "Remaining amounts you've committed but not yet funded."
    },
    {
      label: "Next Payout",
      value: adjustedData.unfunded_commitments > 0 ? `${nextPayout.date}` : "No upcoming payouts",
      numericValue: nextPayout.amount,
      sublabel: adjustedData.unfunded_commitments > 0 ? `Est. ${formatCurrency(nextPayout.amount)}` : "All caught up",
      icon: Calendar,
      tooltip: "Date and estimated amount of your next payout."
    }
  ];

  const kpis = [
    {
      label: "Cash Available",
      value: formatCurrency(adjustedData.cash_available),
      numericValue: adjustedData.cash_available,
      sublabel: "Ready to invest",
      icon: DollarSign,
      tooltip: "Funds ready to invest or withdraw."
    },
    {
      label: "Total Invested",
      value: formatCurrency(adjustedData.total_invested),
      numericValue: adjustedData.total_invested,
      sublabel: "Principal contributed",
      icon: Target,
      tooltip: "Sum of all contributed principal to date."
    },
    {
      label: "Current Value",
      value: formatCurrency(adjustedData.current_value),
      numericValue: adjustedData.current_value,
      sublabel: "Portfolio value",
      icon: TrendingUp,
      tooltip: "Estimated current portfolio value including accrued income."
    },
    {
      label: "Net Return %",
      value: `${netReturn >= 0 ? '+' : ''}${netReturnPercentage}%`,
      numericValue: parseFloat(netReturnPercentage),
      sublabel: "Total return",
      icon: Percent,
      tooltip: "(Current Value + Distributions − Total Invested) ÷ Total Invested."
    },
    {
      label: "MOIC",
      value: `${moic}x`,
      numericValue: parseFloat(moic),
      sublabel: "Money multiple",
      icon: Calculator,
      tooltip: "Multiple on invested capital = (Current Value + Distributions) ÷ Total Invested."
    },
    {
      label: "Portfolio IRR (XIRR)",
      value: `${portfolioIRR}%`,
      numericValue: parseFloat(portfolioIRR),
      sublabel: "Annualized return",
      icon: TrendingUp,
      tooltip: "Annualized return based on actual cashflow timing; net of fees."
    },
    {
      label: "Unfunded Commitments",
      value: formatCurrency(adjustedData.unfunded_commitments),
      numericValue: adjustedData.unfunded_commitments,
      sublabel: "Pending funding",
      icon: Clock,
      tooltip: "Remaining amounts you've committed but not yet funded."
    },
    {
      label: "Active Investments",
      value: adjustedData.active_investments.toString(),
      numericValue: adjustedData.active_investments,
      sublabel: "Holdings count",
      icon: Building2,
      tooltip: "Count of investments currently held."
    }
  ];

  return (
    <div className="space-y-4 overflow-visible">
      {/* Range Controls - Hide in simple mode */}
      {mode === 'pro' && (
        <div className="flex justify-end gap-2">
          <Select 
            value={selectedRange} 
            onValueChange={(value: any) => {
              setSelectedRange(value);
              dashboardAnalytics.rangeChanged(value);
            }}
          >
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1m">1 Month</SelectItem>
              <SelectItem value="3m">3 Months</SelectItem>
              <SelectItem value="6m">6 Months</SelectItem>
              <SelectItem value="1y">1 Year</SelectItem>
              <SelectItem value="ytd">Year to Date</SelectItem>
              <SelectItem value="inception">Since Inception</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      {/* KPI Cards */}
      <div className={`kpiGrid kpiRow grid relative z-20 w-full overflow-visible ${
        mode === 'simple' 
          ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 sm:gap-6' 
          : 'grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4'
      }`} style={{
        gridTemplateColumns: mode === 'simple' 
          ? 'repeat(auto-fit, minmax(200px, 1fr))'
          : 'repeat(auto-fit, minmax(140px, 1fr))'
      }}>
        <TooltipProvider>
          {(mode === 'simple' ? simpleKpis : kpis).map((kpi, index) => {
            return (
              <div 
                key={index} 
                className="kpiCard-wrap"
                >
                  <Card 
                    className={`kpi-card glass-card border-glass-border transition-all duration-300 overflow-hidden ${
                      mode === 'simple' ? 'min-h-[112px]' : 'min-h-[88px]'
                    }`}
                    aria-label={`${kpi.label}: ${kpi.value}`}
                    aria-describedby={openTooltip === kpi.label ? `tooltip-${index}` : undefined}
                  >
                    <CardContent className={mode === 'simple' ? 'p-5' : 'p-3'}>
                      <div className={`flex items-start justify-between ${mode === 'simple' ? 'mb-2' : 'mb-1'}`}>
                        <kpi.icon className={`text-primary ${mode === 'simple' ? 'h-5 w-5' : 'h-3.5 w-3.5'}`} aria-hidden="true" />
                        <Tooltip 
                          open={openTooltip === kpi.label}
                          onOpenChange={(open) => {
                            setOpenTooltip(open ? kpi.label : null);
                            if (open) dashboardAnalytics.kpiTooltipOpened(kpi.label);
                          }}
                        >
                          <TooltipTrigger asChild>
                            <button
                              className="p-0.5"
                              aria-label={`Information about ${kpi.label}`}
                              onClick={(e) => {
                                e.stopPropagation();
                                setOpenTooltip(openTooltip === kpi.label ? null : kpi.label);
                                dashboardAnalytics.kpiTooltipOpened(kpi.label);
                              }}
                            >
                              <Info className={`text-muted-foreground cursor-help ${mode === 'simple' ? 'h-4 w-4' : 'h-3 w-3'}`} />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent id={`tooltip-${index}`}>
                            <p className="max-w-xs">{kpi.tooltip}</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                      <div className={mode === 'simple' ? 'space-y-1' : 'space-y-0.5'}>
                        <div className={`font-bold gradient-text ${mode === 'simple' ? 'text-xl' : 'text-sm'}`}>
                          <AnimatedCounter
                            value={kpi.numericValue || 0}
                            formatFn={() => kpi.value}
                            aria-label={`${kpi.label}: ${kpi.value}`}
                          />
                        </div>
                        <div className={`text-muted-foreground ${mode === 'simple' ? 'text-sm font-medium' : 'text-xs'}`}>{kpi.label}</div>
                        <div className={`text-muted-foreground/80 text-xs`}>{kpi.sublabel}</div>
                      </div>
                    </CardContent>
                  </Card>
              </div>
            );
          })}
        </TooltipProvider>
      </div>
    </div>
  );
}