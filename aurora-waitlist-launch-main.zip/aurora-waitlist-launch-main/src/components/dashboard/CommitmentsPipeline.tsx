import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Clock, Target, Eye, CreditCard, ChevronDown, ChevronUp, ExternalLink } from "lucide-react";
import { useDashboardCollapse } from "@/hooks/useDashboardCollapse";
import { dashboardAnalytics } from "@/utils/analytics";

interface Commitment {
  id: string;
  investment: string;
  commitment_amount: number;
  funded_amount: number;
  funding_percentage: number;
  funding_deadline: string;
  status: "active" | "completed" | "expired";
}

interface WatchlistItem {
  id: string;
  property_name: string;
  funding_progress: number;
  days_left: number;
  target_funding: number;
  current_funding: number;
}

interface CommitmentsPipelineProps {
  commitments: Commitment[];
  watchlist: WatchlistItem[];
  mode?: 'simple' | 'pro';
}

export function CommitmentsPipeline({ commitments, watchlist, mode = 'pro' }: CommitmentsPipelineProps) {
  const { isCollapsed, toggleCollapse } = useDashboardCollapse(mode);
  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-blue-500/20 text-blue-400";
      case "completed": return "bg-green-500/20 text-green-400";
      case "expired": return "bg-red-500/20 text-red-400";
      default: return "bg-gray-500/20 text-gray-400";
    }
  };

  const getDaysLeftColor = (days: number) => {
    if (days <= 7) return "text-red-400";
    if (days <= 30) return "text-yellow-400";
    return "text-green-400";
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Your Commitments */}
      <Card className="glass-card border-glass-border overflow-visible">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={() => toggleCollapse('commitments', (moduleKey, isCollapsed, mode) => {
                  if (isCollapsed) {
                    dashboardAnalytics.moduleCollapsed(moduleKey, mode);
                  } else {
                    dashboardAnalytics.moduleExpanded(moduleKey, mode);
                  }
                })}
                className={`p-1 hover:bg-muted rounded-sm transition-colors focus:ring-2 focus:ring-primary focus:ring-offset-1 ${mode === 'simple' ? 'h-7 w-7' : 'h-6 w-6'}`}
                aria-label={`${isCollapsed('commitments') ? 'Expand' : 'Collapse'} commitments section`}
                aria-expanded={!isCollapsed('commitments')}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    toggleCollapse('commitments', (moduleKey, isCollapsed, mode) => {
                      if (isCollapsed) {
                        dashboardAnalytics.moduleCollapsed(moduleKey, mode);
                      } else {
                        dashboardAnalytics.moduleExpanded(moduleKey, mode);
                      }
                    });
                  }
                }}
              >
                {isCollapsed('commitments') ? (
                  <ChevronDown className="h-4 w-4" />
                ) : (
                  <ChevronUp className="h-4 w-4" />
                )}
              </button>
              <Target className={`text-primary ${mode === 'simple' ? 'h-5 w-5' : 'h-4 w-4'}`} />
              <CardTitle className={mode === 'simple' ? 'text-lg font-semibold' : 'text-base'}>Your Commitments</CardTitle>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => {
                dashboardAnalytics.viewDetailsClicked('commitments', mode, '/investments?tab=commitments');
                window.location.href = '/investments?tab=commitments';
              }}
              className={mode === 'simple' ? 'text-sm h-8 px-3' : 'text-xs h-7 px-2'}
            >
              <ExternalLink className={`mr-1 ${mode === 'simple' ? 'h-4 w-4' : 'h-3 w-3'}`} />
              View Details
            </Button>
          </div>
        </CardHeader>
        <CardContent className={`overflow-visible transition-all duration-200 ${
          isCollapsed('commitments') ? 'h-0 overflow-hidden opacity-0 p-0' : 
          `animate-fade-in ${mode === 'simple' ? 'p-6 space-y-4' : 'p-4 space-y-3'}`
        }`}>
          {commitments.length > 0 ? (
            <div className="space-y-4">
              {commitments.map((commitment) => (
                <div key={commitment.id} className="p-4 border border-glass-border rounded-lg bg-muted/10">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-medium">{commitment.investment}</h4>
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <span>Commitment: ${commitment.commitment_amount.toLocaleString()}</span>
                        <Badge className={getStatusColor(commitment.status)}>
                          {commitment.status}
                        </Badge>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground">Deadline</div>
                      <div className="text-sm font-medium">
                        {new Date(commitment.funding_deadline).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Funded Progress</span>
                      <span>{commitment.funding_percentage.toFixed(0)}%</span>
                    </div>
                    <Progress value={commitment.funding_percentage} className="h-2" />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>${commitment.funded_amount.toLocaleString()} funded</span>
                      <span>${(commitment.commitment_amount - commitment.funded_amount).toLocaleString()} remaining</span>
                    </div>
                  </div>

                  {commitment.status === "active" && commitment.funding_percentage < 100 && (
                    <Button 
                      className="w-full mt-3 bg-gradient-primary hover:shadow-neon" 
                      size="sm"
                      onClick={() => dashboardAnalytics.commitmentCtaClicked(commitment.id)}
                    >
                      <CreditCard className="h-4 w-4 mr-2" />
                      Complete Funding
                    </Button>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Target className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No active commitments.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Watchlist */}
      <Card className="glass-card border-glass-border overflow-visible">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                onClick={() => toggleCollapse('watchlist', (moduleKey, isCollapsed, mode) => {
                  if (isCollapsed) {
                    dashboardAnalytics.moduleCollapsed(moduleKey, mode);
                  } else {
                    dashboardAnalytics.moduleExpanded(moduleKey, mode);
                  }
                })}
                className={`p-1 hover:bg-muted rounded-sm transition-colors focus:ring-2 focus:ring-primary focus:ring-offset-1 ${mode === 'simple' ? 'h-7 w-7' : 'h-6 w-6'}`}
                aria-label={`${isCollapsed('watchlist') ? 'Expand' : 'Collapse'} watchlist section`}
                aria-expanded={!isCollapsed('watchlist')}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    toggleCollapse('watchlist', (moduleKey, isCollapsed, mode) => {
                      if (isCollapsed) {
                        dashboardAnalytics.moduleCollapsed(moduleKey, mode);
                      } else {
                        dashboardAnalytics.moduleExpanded(moduleKey, mode);
                      }
                    });
                  }
                }}
              >
                {isCollapsed('watchlist') ? (
                  <ChevronDown className="h-4 w-4" />
                ) : (
                  <ChevronUp className="h-4 w-4" />
                )}
              </button>
              <Eye className={`text-primary ${mode === 'simple' ? 'h-5 w-5' : 'h-4 w-4'}`} />
              <CardTitle className={mode === 'simple' ? 'text-lg font-semibold' : 'text-base'}>Watchlist</CardTitle>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => {
                dashboardAnalytics.viewDetailsClicked('watchlist', mode, '/properties?tab=watchlist');
                window.location.href = '/properties?tab=watchlist';
              }}
              className={mode === 'simple' ? 'text-sm h-8 px-3' : 'text-xs h-7 px-2'}
            >
              <ExternalLink className={`mr-1 ${mode === 'simple' ? 'h-4 w-4' : 'h-3 w-3'}`} />
              View Details
            </Button>
          </div>
        </CardHeader>
        <CardContent className={`overflow-visible transition-all duration-200 ${
          isCollapsed('watchlist') ? 'h-0 overflow-hidden opacity-0 p-0' : 
          `animate-fade-in ${mode === 'simple' ? 'p-6 space-y-4' : 'p-4 space-y-3'}`
        }`}>
          {watchlist.length > 0 ? (
            <div className="space-y-4">
              {watchlist.map((item) => (
                <div key={item.id} className="p-4 border border-glass-border rounded-lg bg-muted/10">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="font-medium">{item.property_name}</h4>
                      <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        <span className={getDaysLeftColor(item.days_left)}>
                          {item.days_left} days left
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground">Target</div>
                      <div className="text-sm font-medium">
                        ${item.target_funding.toLocaleString()}
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Funding Progress</span>
                      <span>{item.funding_progress.toFixed(0)}%</span>
                    </div>
                    <Progress value={item.funding_progress} className="h-2" />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>${item.current_funding.toLocaleString()} raised</span>
                      <span>${(item.target_funding - item.current_funding).toLocaleString()} needed</span>
                    </div>
                  </div>

                  <Button variant="outline" className="w-full mt-3" size="sm">
                    <Eye className="h-4 w-4 mr-2" />
                    View Details
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Eye className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground mb-2">No items in watchlist</p>
              <Button variant="outline" size="sm" onClick={() => window.location.href = '/properties'}>
                Browse Properties
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}