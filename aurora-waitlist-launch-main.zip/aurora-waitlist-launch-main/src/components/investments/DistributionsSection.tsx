import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Calendar, DollarSign, TrendingUp } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { EmptyState } from '@/components/EmptyState';

interface UpcomingPayout {
  id: string;
  investment: string;
  date: string;
  estimated_amount: number;
  status: 'scheduled' | 'processing' | 'paid';
}

interface MonthlyDistribution {
  month: string;
  ordinary_income: number;
  return_of_capital: number;
  total: number;
}

interface DistributionsSectionProps {
  upcomingPayouts: UpcomingPayout[];
  monthlyDistributions: MonthlyDistribution[];
  currency: string;
}

export function DistributionsSection({ 
  upcomingPayouts, 
  monthlyDistributions, 
  currency 
}: DistributionsSectionProps) {
  const formatCurrency = (amount: number) => {
    const symbol = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : '£';
    return `${symbol}${amount.toLocaleString()}`;
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      scheduled: "outline",
      processing: "default",
      paid: "secondary"
    };
    
    return (
      <Badge variant={variants[status] || "outline"}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const totalIncome12M = monthlyDistributions.reduce((sum, month) => sum + month.ordinary_income, 0);
  const totalROC12M = monthlyDistributions.reduce((sum, month) => sum + month.return_of_capital, 0);
  const totalDistributions12M = totalIncome12M + totalROC12M;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Upcoming Payouts */}
      <Card className="glass-card border-glass-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Upcoming Payouts
          </CardTitle>
        </CardHeader>
        <CardContent>
          {upcomingPayouts.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No scheduled payouts</p>
            </div>
          ) : (
            <div className="overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Investment</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {upcomingPayouts.map((payout) => (
                    <TableRow key={payout.id}>
                      <TableCell className="font-medium">{payout.investment}</TableCell>
                      <TableCell>{new Date(payout.date).toLocaleDateString()}</TableCell>
                      <TableCell>{formatCurrency(payout.estimated_amount)}</TableCell>
                      <TableCell>{getStatusBadge(payout.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Last 12 Months Distributions */}
      <Card className="glass-card border-glass-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Last 12 Months Distributions
          </CardTitle>
        </CardHeader>
        <CardContent>
          {monthlyDistributions.length === 0 ? (
            <div className="text-center py-8">
              <DollarSign className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No distribution history</p>
            </div>
          ) : (
            <>
              <div className="h-64 w-full mb-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyDistributions}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="month" 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                    />
                    <YAxis 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                      tickFormatter={(value) => formatCurrency(value)}
                    />
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: 'hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                      formatter={(value: any, name: string) => [
                        formatCurrency(value), 
                        name === 'ordinary_income' ? 'Ordinary Income' : 'Return of Capital'
                      ]}
                    />
                    <Bar 
                      dataKey="ordinary_income" 
                      stackId="a" 
                      fill="hsl(var(--primary))" 
                      name="ordinary_income"
                    />
                    <Bar 
                      dataKey="return_of_capital" 
                      stackId="a" 
                      fill="hsl(var(--primary) / 0.6)" 
                      name="return_of_capital"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              
              {/* Totals Summary */}
              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border/50">
                <div className="text-center">
                  <div className="text-sm text-muted-foreground">12-mo Income</div>
                  <div className="font-semibold text-primary">{formatCurrency(totalIncome12M)}</div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-muted-foreground">12-mo ROC</div>
                  <div className="font-semibold">{formatCurrency(totalROC12M)}</div>
                </div>
                <div className="text-center">
                  <div className="text-sm text-muted-foreground">Total</div>
                  <div className="font-semibold">{formatCurrency(totalDistributions12M)}</div>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}