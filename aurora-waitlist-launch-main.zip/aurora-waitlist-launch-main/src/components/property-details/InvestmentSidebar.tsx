import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { 
  DollarSign, 
  Calculator, 
  Bell, 
  Bookmark, 
  TrendingUp, 
  Calendar,
  AlertCircle,
  CheckCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface InvestmentSidebarProps {
  property: {
    id: string;
    title: string;
    minimum_investment: number;
    expected_annual_return: number;
    target_funding: number;
    current_funding: number;
    property_status: string;
    funding_deadline?: string;
  };
  className?: string;
  isMobile?: boolean;
}

export function InvestmentSidebar({ property, className, isMobile = false }: InvestmentSidebarProps) {
  const [investmentAmount, setInvestmentAmount] = useState(property.minimum_investment);
  const [watchlistEnabled, setWatchlistEnabled] = useState(false);
  const [reminderEnabled, setReminderEnabled] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);

  const fundingPercentage = (property.current_funding / property.target_funding) * 100;
  const isFullyFunded = property.property_status === 'fully_funded';
  const remaining = property.target_funding - property.current_funding;

  // Calculate projected returns
  const projectedAnnualIncome = (investmentAmount * property.expected_annual_return) / 100;
  const projectedMonthlyIncome = projectedAnnualIncome / 12;
  const projectedTotalReturn = investmentAmount * 1.8; // 1.8x equity multiple assumption

  const handleAmountChange = (value: string) => {
    const numValue = parseInt(value.replace(/[^0-9]/g, '')) || 0;
    const rounded = Math.max(property.minimum_investment, Math.round(numValue / 1000) * 1000);
    setInvestmentAmount(rounded);
  };

  const incrementAmount = (increment: number) => {
    const newAmount = investmentAmount + increment;
    setInvestmentAmount(Math.max(property.minimum_investment, newAmount));
  };

  const getTimeLeft = () => {
    if (!property.funding_deadline) return null;
    const deadline = new Date(property.funding_deadline);
    const now = new Date();
    const diffTime = deadline.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 0) return 'Expired';
    if (diffDays === 1) return '1 day left';
    if (diffDays <= 7) return `${diffDays} days left`;
    return `${diffDays} days left`;
  };

  const timeLeft = getTimeLeft();

  return (
    <div className={cn("space-y-4", className)}>
      {/* Investment Calculator */}
      <Card className="glass-card border-glass-border sticky top-24">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-primary" />
            Investment Calculator
          </CardTitle>
          {timeLeft && (
            <Badge 
              variant="outline" 
              className={cn(
                "w-fit",
                timeLeft.includes('day') && parseInt(timeLeft) <= 7 ? "border-red-500/50 text-red-400" : "border-yellow-500/50 text-yellow-400"
              )}
            >
              <Calendar className="h-3 w-3 mr-1" />
              {timeLeft}
            </Badge>
          )}
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Investment Amount Input */}
          <div className="space-y-2">
            <Label htmlFor="investment-amount">Investment Amount</Label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="investment-amount"
                value={investmentAmount.toLocaleString()}
                onChange={(e) => handleAmountChange(e.target.value)}
                className="pl-9 glass border-glass-border text-right font-mono"
                placeholder="0"
              />
            </div>
            
            {/* Quick Amount Buttons */}
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => incrementAmount(5000)}
                className="flex-1 glass border-glass-border"
              >
                +$5K
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => incrementAmount(10000)}
                className="flex-1 glass border-glass-border"
              >
                +$10K
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => incrementAmount(25000)}
                className="flex-1 glass border-glass-border"
              >
                +$25K
              </Button>
            </div>
            
            <div className="text-xs text-muted-foreground">
              Minimum: ${property.minimum_investment.toLocaleString()}
            </div>
          </div>

          <Separator className="bg-glass-border" />

          {/* Projected Returns */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              <span className="font-medium">Projected Returns</span>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="text-muted-foreground">Annual Income</div>
                <div className="font-medium text-primary">
                  ${projectedAnnualIncome.toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-muted-foreground">Monthly Income</div>
                <div className="font-medium">
                  ${projectedMonthlyIncome.toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-muted-foreground">Total Return (3-5Y)</div>
                <div className="font-medium text-green-400">
                  ${projectedTotalReturn.toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-muted-foreground">Profit</div>
                <div className="font-medium text-green-400">
                  ${(projectedTotalReturn - investmentAmount).toLocaleString()}
                </div>
              </div>
            </div>

            <div className="p-3 bg-muted/20 rounded-lg border border-muted/50">
              <p className="text-xs text-muted-foreground">
                Projections based on {property.expected_annual_return}% target IRR and 1.8x equity multiple. 
                Actual returns may vary.
              </p>
            </div>
          </div>

          <Separator className="bg-glass-border" />

          {/* Investment CTA */}
          {isFullyFunded ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-yellow-600">
                <AlertCircle className="h-4 w-4" />
                <span className="text-sm font-medium">Fully Funded</span>
              </div>
              <Button 
                variant="outline" 
                className="w-full glass border-glass-border"
                disabled
              >
                Join Waitlist for Secondary
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {/* KYC/Accreditation Status */}
              <div className="p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <AlertCircle className="h-4 w-4 text-blue-400" />
                  <span className="text-sm font-medium text-blue-400">Accreditation Required</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Complete your investor verification to proceed with investment.
                </p>
              </div>

              <Button 
                className="w-full bg-gradient-primary hover:shadow-neon" 
                size={isMobile ? "lg" : "default"}
                disabled={investmentAmount < property.minimum_investment}
              >
                <DollarSign className="h-4 w-4 mr-2" />
                Invest ${investmentAmount.toLocaleString()}
              </Button>
            </div>
          )}

          <Separator className="bg-glass-border" />

          {/* Watchlist & Reminders */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bookmark className="h-4 w-4" />
                <Label htmlFor="watchlist" className="text-sm">Add to Watchlist</Label>
              </div>
              <Switch
                id="watchlist"
                checked={watchlistEnabled}
                onCheckedChange={setWatchlistEnabled}
              />
            </div>

            {!isFullyFunded && property.funding_deadline && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="h-4 w-4" />
                  <Label htmlFor="reminder" className="text-sm">Deadline Reminder</Label>
                </div>
                <Switch
                  id="reminder"
                  checked={reminderEnabled}
                  onCheckedChange={setReminderEnabled}
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <Card className="glass-card border-glass-border">
        <CardContent className="p-4 space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Funded</span>
            <span className="font-medium">{fundingPercentage.toFixed(1)}%</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Remaining</span>
            <span className="font-medium">${remaining.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Investors</span>
            <span className="font-medium">247</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Avg Investment</span>
            <span className="font-medium">$28,500</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}