import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Info } from 'lucide-react';
import { AnimatedCounter } from '@/components/AnimatedCounter';
import { analytics } from '@/utils/analytics';

interface KPIData {
  totalInvested: number;
  currentValue: number;
  netReturnPercent: number;
  dpi: number;
  tvpi: number;
  irr: number;
  incomeYTD: number;
  propertiesCount: number;
}

interface InvestmentKPISummaryProps {
  data: KPIData;
  currency: string;
}

const tooltips = {
  totalInvested: "Sum of all contributed principal to date.",
  currentValue: "Estimated current portfolio value including accrued income.",
  netReturnPercent: "(Current Value + Distributions − Total Invested) ÷ Total Invested.",
  dpi: "Distributions to Paid-In Capital = Total Distributions ÷ Total Invested.",
  tvpi: "Total Value to Paid-In Capital = (Current Value + Distributions) ÷ Total Invested.",
  irr: "Annualized return based on actual cashflow timing; net of fees.",
  incomeYTD: "Total distributions and income received year-to-date.",
  propertiesCount: "Number of active property investments in portfolio."
};

export function InvestmentKPISummary({ data, currency }: InvestmentKPISummaryProps) {
  const formatCurrency = (amount: number) => {
    const symbol = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : '£';
    return `${symbol}${amount.toLocaleString()}`;
  };

  const kpis = [
    {
      title: "Total Invested",
      value: data.totalInvested,
      format: "currency",
      tooltip: tooltips.totalInvested,
      key: "totalInvested"
    },
    {
      title: "Current Value", 
      value: data.currentValue,
      format: "currency",
      tooltip: tooltips.currentValue,
      key: "currentValue"
    },
    {
      title: "Net Return %",
      value: data.netReturnPercent,
      format: "percentage",
      tooltip: tooltips.netReturnPercent,
      key: "netReturnPercent"
    },
    {
      title: "DPI",
      value: data.dpi,
      format: "ratio",
      tooltip: tooltips.dpi,
      key: "dpi"
    },
    {
      title: "TVPI",
      value: data.tvpi,
      format: "ratio", 
      tooltip: tooltips.tvpi,
      key: "tvpi"
    },
    {
      title: "IRR (XIRR)",
      value: data.irr,
      format: "percentage",
      tooltip: tooltips.irr,
      key: "irr"
    },
    {
      title: "Income YTD",
      value: data.incomeYTD,
      format: "currency",
      tooltip: tooltips.incomeYTD,
      key: "incomeYTD"
    },
    {
      title: "# of Properties",
      value: data.propertiesCount,
      format: "number",
      tooltip: tooltips.propertiesCount,
      key: "propertiesCount"
    }
  ];

  const formatValue = (value: number, format: string) => {
    switch (format) {
      case "currency":
        return formatCurrency(value);
      case "percentage":
        return `${value.toFixed(2)}%`;
      case "ratio":
        return `${value.toFixed(2)}x`;
      case "number":
        return value.toString();
      default:
        return value.toString();
    }
  };

  return (
    <TooltipProvider>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4 overflow-visible">
        {kpis.map((kpi) => (
          <div key={kpi.key} className="card-wrapper" style={{ zIndex: 1 }}>
            <Card className="glass-card border-glass-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {kpi.title}
                </CardTitle>
                <Tooltip>
                  <TooltipTrigger 
                    asChild
                    onFocus={() => analytics.track('kpi_tooltip_opened', { kpi: kpi.key })}
                    onClick={() => analytics.track('kpi_tooltip_opened', { kpi: kpi.key })}
                  >
                    <button className="text-muted-foreground hover:text-primary focus:text-primary focus:outline-none">
                      <Info className="h-4 w-4" />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="max-w-xs">{kpi.tooltip}</p>
                  </TooltipContent>
                </Tooltip>
              </CardHeader>
              <CardContent>
                <div 
                  className="text-2xl font-bold gradient-text"
                  aria-label={`${kpi.title}: ${formatValue(kpi.value, kpi.format)}`}
                >
                  {kpi.format === "currency" || kpi.format === "number" ? (
                    <AnimatedCounter 
                      value={kpi.value} 
                      formatFn={kpi.format === "currency" ? 
                        (val: number) => formatCurrency(val) : 
                        (val: number) => val.toString()
                      }
                    />
                  ) : (
                    formatValue(kpi.value, kpi.format)
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        ))}
      </div>
    </TooltipProvider>
  );
}